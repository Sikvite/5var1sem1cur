import matplotlib.pyplot as plt

potato_besprice = [45,45,40,80,27,54]
potato_jitprice = [35,40,40,33,42,61]
potato_volprice = [35,35,40,10,37,60]
cabbage_besprice = [50,45,40,44,39,59]
cabbage_jitprice = [30,40,40,45,29,37]
cabbage_volprice = [30,35,40,31,53,74]
onion_besprice = [70,60,60,35,70,43]
onion_jitprice = [50,50,50,32,31,49]
onion_volprice = [45,45,60,46,41,89]

days = ['02.11.2016','14.11.2016','22.11.2016','13.12.2016','25.12.2016','29,12,2016']

plt.plot(days,potato_besprice,label = "Карт.Бесарабський")
plt.plot(days,potato_jitprice,label = "Карт.Житній")
plt.plot(days,potato_volprice,label = "Карт.Володимирський")
plt.plot(days,cabbage_besprice,label = "Кап.Бесарабський")
plt.plot(days,cabbage_jitprice,label = "Кап.Житній")
plt.plot(days,cabbage_volprice,label = "Кап.Володимирський")
plt.plot(days,onion_besprice,label = "Циб.Бесарабський")
plt.plot(days,onion_jitprice,label = "Циб.Житній")
plt.plot(days,onion_volprice,label = "Циб.Володимирський")
plt.xlabel("Дата")
plt.ylabel("Ціна")
plt.legend()
plt.grid(True)

def showplot():
    plt.show()