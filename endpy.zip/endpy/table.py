from prettytable import PrettyTable
from data import dt

x = PrettyTable()

x.field_names = ['Дата', 'Ринок', 'Ціна картоплі', 'Ціна Капусти', 'Ціна капусти']

for i in range(0, len(dt)):

    x.add_rows(
        [
            dt[i]
        ]
    )

def opentabble():
    print('\nАналіз ринкових цін')
    print(x)

print(opentabble())