import json
from price import nounlist1
from markets import nounlist2

def convertToJSON():
    with open("C:\code\endpy\price_json.json", "w") as write_file:
        json.dump(nounlist1, write_file)
def convertInJSON():
    with open("C:\code\endpy\markets_json.json", "w") as write_file:
        json.dump(nounlist2, write_file)